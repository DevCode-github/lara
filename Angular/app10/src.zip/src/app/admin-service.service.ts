import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminServiceService {

  hidden = false;
  constructor(private httpClient: HttpClient) { }

  signup(appuser :any){
    return this.httpClient.post("http://localhost:9091/appuser/signup", appuser)
  }
  login(appuser :any){
    return this.httpClient.post("http://localhost:9091/appuser/login", appuser)
  }
  forgot(appuser :any){
    return this.httpClient.post("http://localhost:9091/appuser/forgot", appuser)
  }
  reset(appuser :any){
    return this.httpClient.post("http://localhost:9091/appuser/reset", appuser)
  }
  upload(imageFile :any){
    return this.httpClient.post("http://localhost:9091/appuser/upload", imageFile)
  }
  fetch(id :any){
    return this.httpClient.post("http://localhost:9091/appuser/fetch", id)
  }
  getBook(){
    return this.httpClient.get("http://localhost:9091/appuser/fetchbooks")
  }
  update(appUser :any){
    return this.httpClient.post("http://localhost:9091/appuser/update",appUser)
  }
}
